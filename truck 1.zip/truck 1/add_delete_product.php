<?php
session_start();

// Connect to database
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "omar";

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission for adding a product
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_product'])) {
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];

    // Handle file upload
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["product_image"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Ensure the uploads directory exists
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // Check if image file is an actual image or fake image
    $check = getimagesize($_FILES["product_image"]["tmp_name"]);
    if ($check !== false) {
        if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file)) {
            // File is valid, and was successfully uploaded
            $stmt = $conn->prepare("INSERT INTO products (name, price, image_path) VALUES (?, ?, ?)");
            $stmt->bind_param("sds", $product_name, $product_price, $target_file);
            $stmt->execute();
            $stmt->close();

            echo "<script>alert('Product added successfully');</script>";
        } else {
            echo "<script>alert('Sorry, there was an error uploading your file.');</script>";
        }
    } else {
        echo "<script>alert('File is not an image.');</script>";
    }
}

// Handle form submission for adding an accessory
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_accessory'])) {
    $accessory_name = $_POST['accessory_name'];
    $accessory_price = $_POST['accessory_price'];

    // Handle file upload
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["accessory_image"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Ensure the uploads directory exists
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // Check if image file is an actual image or fake image
    $check = getimagesize($_FILES["accessory_image"]["tmp_name"]);
    if ($check !== false) {
        if (move_uploaded_file($_FILES["accessory_image"]["tmp_name"], $target_file)) {
            // File is valid, and was successfully uploaded
            $stmt = $conn->prepare("INSERT INTO accessories (name, price, image_path) VALUES (?, ?, ?)");
            $stmt->bind_param("sds", $accessory_name, $accessory_price, $target_file);
            $stmt->execute();
            $stmt->close();

            echo "<script>alert('Accessory added successfully');</script>";
        } else {
            echo "<script>alert('Sorry, there was an error uploading your file.');</script>";
        }
    } else {
        echo "<script>alert('File is not an image.');</script>";
    }
}

// Handle form submission for adding a service
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_service'])) {
    $service_name = $_POST['service_name'];
    $service_description = $_POST['service_description'];

    // Handle file upload
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["service_image"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Ensure the uploads directory exists
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // Check if image file is an actual image or fake image
    $check = getimagesize($_FILES["service_image"]["tmp_name"]);
    if ($check !== false) {
        if (move_uploaded_file($_FILES["service_image"]["tmp_name"], $target_file)) {
            // File is valid, and was successfully uploaded
            $stmt = $conn->prepare("INSERT INTO services (name, description, image_path) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $service_name, $service_description, $target_file);
            $stmt->execute();
            $stmt->close();

            echo "<script>alert('Service added successfully');</script>";
        } else {
            echo "<script>alert('Sorry, there was an error uploading your file.');</script>";
        }
    } else {
        echo "<script>alert('File is not an image.');</script>";
    }
}

// Handle product deletion
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['delete'])) {
    $product_id = $_GET['delete'];

    $stmt = $conn->prepare("SELECT image_path FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $image_path = $row['image_path'];
    $stmt->close();

    if (file_exists($image_path)) {
        unlink($image_path); // Delete the file
    }

    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $stmt->close();

    echo "<script>alert('Product deleted successfully');</script>";
}

// Handle accessory deletion
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['delete_accessory'])) {
    $accessory_id = $_GET['delete_accessory'];

    $stmt = $conn->prepare("SELECT image_path FROM accessories WHERE id = ?");
    $stmt->bind_param("i", $accessory_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $image_path = $row['image_path'];
    $stmt->close();

    if (file_exists($image_path)) {
        unlink($image_path); // Delete the file
    }

    $stmt = $conn->prepare("DELETE FROM accessories WHERE id = ?");
    $stmt->bind_param("i", $accessory_id);
    $stmt->execute();
    $stmt->close();

    echo "<script>alert('Accessory deleted successfully');</script>";
}

// Handle service deletion
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['delete_service'])) {
    $service_id = $_GET['delete_service'];

    $stmt = $conn->prepare("SELECT image_path FROM services WHERE id = ?");
    $stmt->bind_param("i", $service_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $image_path = $row['image_path'];
    $stmt->close();

    if (file_exists($image_path)) {
        unlink($image_path); // Delete the file
    }

    $stmt = $conn->prepare("DELETE FROM services WHERE id = ?");
    $stmt->bind_param("i", $service_id);
    $stmt->execute();
    $stmt->close();

    echo "<script>alert('Service deleted successfully');</script>";
}

// Fetch all products
$product_result = $conn->query("SELECT * FROM products");

// Fetch all accessories
$accessory_result = $conn->query("SELECT * FROM accessories");

// Fetch all services
$service_result = $conn->query("SELECT * FROM services");

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/ico" href="images/icon.ico">
    <title>Al-Khatib Truck Repair Shop</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h1 {
            margin-bottom: 20px;
            color: #333;
            font-size: 24px;
            text-align: center;
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
        }

        form {
            margin-bottom: 40px;
        }

        .txt_field {
            position: relative;
            margin-bottom: 30px;
        }

        .txt_field input[type="text"],
        .txt_field input[type="number"],
        .txt_field input[type="file"],
        .txt_field textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            outline: none;
            transition: border-color 0.3s;
        }

        .txt_field input[type="text"]:focus,
        .txt_field input[type="number"]:focus,
        .txt_field input[type="file"]:focus,
        .txt_field textarea:focus {
            border-color: #333;
        }

        .txt_field label {
            position: absolute;
            top: -20px;
            left: 10px;
            color: #999;
            pointer-events: none;
            transition: all 0.3s;
        }

        .txt_field input[type="text"]:focus ~ label,
        .txt_field input[type="number"]:focus ~ label,
        .txt_field input[type="file"]:focus ~ label,
        .txt_field input[type="text"]:valid ~ label,
        .txt_field input[type="number"]:valid ~ label,
        .txt_field input[type="file"]:valid ~ label {
            top: -20px;
            left: 10px;
            color: #333;
            font-size: 12px;
        }

        .txt_field textarea:focus ~ label,
        .txt_field textarea:valid ~ label {
            top: -35px;
            left: 10px;
            color: #333;
            font-size: 12px;
        }

        .txt_field textarea {
            white-space: pre-wrap; 
        }

        input[type="submit"] {
            width: 100%;
            background: #002A54;
            color: #fff;
            border: none;
            padding: 10px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
            transition: background 0.3s;
        }

        input[type="submit"]:hover {
            background: #E4711C;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background: #f4f4f4;
        }

        td img {
            max-width: 100px;
            height: auto;
            border-radius: 5px;
        }

        td a {
            color: #e60000;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s;
        }

        td a:hover {
            color: #cc0000;
        }

        .service-list {
            list-style-type: disc;
            margin: 10px 0 0 20px;
            padding: 0;
        }
    </style>
</head>
<body>
    <header>
        <img src="images/logo.PNG">
        <nav>
            <ul>
                <li><a href="home.php" class="active">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="services.php">Services</a></li>
                <li><a href="products.html">Products</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <section>
            <div class="container">
                <h1>Manage Parts</h1>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" enctype="multipart/form-data">
                    <div class="txt_field">
                        <input type="text" name="product_name" required>
                        <span></span>
                        <label>Part Name</label>
                    </div>
                    <div class="txt_field">
                        <input type="number" name="product_price" step="0.01" required>
                        <span></span>
                        <label>Part Price</label>
                    </div>
                    <div class="txt_field">
                        <input type="file" name="product_image" required>
                        <span></span>
                        <label>Part Image</label>
                    </div>
                    <input name="add_product" type="submit" value="Add Part">
                </form>

                <h1>Delete Existing Parts</h1>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Part Name</th>
                            <th>Part Price</th>
                            <th>Part Image</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $product_result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo $row['name']; ?></td>
                                <td><?php echo $row['price']; ?></td>
                                <td><img src="<?php echo $row['image_path']; ?>" alt="Part Image" width="100"></td>
                                <td>
                                    <a href="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>?delete=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this part?');">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section>
            <div class="container">
                <h1>Manage Accessories</h1>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" enctype="multipart/form-data">
                    <div class="txt_field">
                        <input type="text" name="accessory_name" required>
                        <span></span>
                        <label>Accessory Name</label>
                    </div>
                    <div class="txt_field">
                        <input type="number" name="accessory_price" step="0.01" required>
                        <span></span>
                        <label>Accessory Price</label>
                    </div>
                    <div class="txt_field">
                        <input type="file" name="accessory_image" required>
                        <span></span>
                        <label>Accessory Image</label>
                    </div>
                    <input name="add_accessory" type="submit" value="Add Accessory">
                </form>

                <h1>Delete Existing Accessories</h1>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Accessory Name</th>
                            <th>Accessory Price</th>
                            <th>Accessory Image</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $accessory_result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo $row['name']; ?></td>
                                <td><?php echo $row['price']; ?></td>
                                <td><img src="<?php echo $row['image_path']; ?>" alt="Accessory Image" width="100"></td>
                                <td>
                                    <a href="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>?delete_accessory=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this accessory?');">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section>
            <div class="container">
                <h1>Manage Services</h1>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" enctype="multipart/form-data">
                    <div class="txt_field">
                        <input type="text" name="service_name" required>
                        <span></span>
                        <label>Service Name</label>
                    </div>
                    <div class="txt_field">
                        <label>Service Description</label>
                        <textarea name="service_description" rows="4" required></textarea>
                        <span></span>
                    </div>
                    <div class="txt_field">
                        <input type="file" name="service_image" required>
                        <span></span>
                        <label>Service Image</label>
                    </div>
                    <input name="add_service" type="submit" value="Add Service">
                </form>

                <h1>Delete Existing Services</h1>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Service Name</th>
                            <th>Service Description</th>
                            <th>Service Image</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $service_result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo $row['name']; ?></td>
                                <td><ul class="service-list"><?php echo nl2br($row['description']); ?></ul></td>
                                <td><img src="<?php echo $row['image_path']; ?>" alt="Service Image" width="100"></td>
                                <td>
                                    <a href="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>?delete_service=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this service?');">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Al-Khatib Truck Repair Shop</p>
    </footer>
</body>
</html>
