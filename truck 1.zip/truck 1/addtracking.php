<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/ico" href="images/icon.ico">
    <title>Al-Khatib Truck Repair Shop - Add Tracking Details</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        main {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        section {
            margin-bottom: 20px;
        }

        h1 {
            text-align: center;
            color: #333;
            font-size: 24px;
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
            color: #555;
        }

        input[type="text"],
        input[type="date"],
        input[type="number"],
        input[type="file"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            outline: none;
            transition: border-color 0.3s;
        }

        input[type="text"]:focus,
        input[type="date"]:focus,
        input[type="number"]:focus,
        input[type="file"]:focus,
        textarea:focus {
            border-color: #333;
        }

        textarea {
            resize: vertical;
        }

        input[type="submit"] {
            width: 100%;
            background: #002A54;
            color: #fff;
            border: none;
            padding: 10px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
            transition: background 0.3s;
        }

        input[type="submit"]:hover {
            background: #E4711C;
        }

        p {
            text-align: center;
            color: green;
            font-weight: bold;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background: #f4f4f4;
        }

        .delete-link {
            color: #e60000;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s;
        }

        .delete-link:hover {
            color: #cc0000;
        }
    </style>
</head>
<body>
    <header>
        <img src="images/logo.PNG" alt="Al-Khatib Truck Repair Shop Logo" class="logo">
        <nav>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="services.php">Services</a></li>
                <li><a href="products.html">Products</a></li>
                <li><a href="tracking.php" class="active">Tracking</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section>
            <h1>Add Tracking Details</h1>
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $servername = "localhost";
                $dbusername = "root";
                $dbpassword = "";
                $dbname = "omar";

                // Create connection
                $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // File upload path
                $target_dir = "billImage/";
                $target_file = $target_dir . basename($_FILES["billImage"]["name"]);
                $uploadOk = 1;
                $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

                // Check if the billImage directory exists and is writable
                if (!is_dir($target_dir) || !is_writable($target_dir)) {
                    die("The billImage directory does not exist or is not writable.");
                }

                // Check if image file is a actual image or fake image
                $check = getimagesize($_FILES["billImage"]["tmp_name"]);
                if ($check !== false) {
                    $uploadOk = 1;
                } else {
                    echo "File is not an image.";
                    $uploadOk = 0;
                }

                // Allow certain file formats
                if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
                    && $imageFileType != "gif") {
                    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                    $uploadOk = 0;
                }

                // Check if $uploadOk is set to 0 by an error
                if ($uploadOk == 0) {
                    echo "Sorry, your file was not uploaded.";
                // if everything is ok, try to upload file
                } else {
                    if (move_uploaded_file($_FILES["billImage"]["tmp_name"], $target_file)) {
                        // Prepare and bind
                        $stmt = $conn->prepare("INSERT INTO TrackingDetails (truckNumber, currentStatus, estimatedCompletion, spareParts, totalCost, billImage) VALUES (?, ?, ?, ?, ?, ?)");
                        $stmt->bind_param("ssssds", $truckNumber, $currentStatus, $estimatedCompletion, $spareParts, $totalCost, $target_file);

                        // Set parameters and execute
                        $truckNumber = $_POST['truckNumber'];
                        $currentStatus = $_POST['currentStatus'];
                        $estimatedCompletion = $_POST['estimatedCompletion'];
                        $spareParts = $_POST['spareParts'];
                        $totalCost = $_POST['totalCost'];

                        if ($stmt->execute()) {
                            echo "<p>New record created successfully</p>";
                        } else {
                            echo "<p>Error: " . $stmt->error . "</p>";
                        }

                        $stmt->close();
                    } else {
                        echo "Sorry, there was an error uploading your file.";
                    }
                }

                $conn->close();
            }

            // Handle deletion
            if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['delete'])) {
                $id = intval($_GET['delete']);

                $servername = "localhost";
                $dbusername = "root";
                $dbpassword = "";
                $dbname = "omar";

                // Create connection
                $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Prepare and bind
                $stmt = $conn->prepare("DELETE FROM TrackingDetails WHERE id = ?");
                $stmt->bind_param("i", $id);

                if ($stmt->execute()) {
                    echo "<p>Record deleted successfully</p>";
                } else {
                    echo "<p>Error: " . $stmt->error . "</p>";
                }

                $stmt->close();
                $conn->close();
            }
            ?>

            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
                <label for="truckNumber">Truck Number:</label>
                <input type="text" id="truckNumber" name="truckNumber" required><br><br>
                
                <label for="currentStatus">Current Status:</label>
                <input type="text" id="currentStatus" name="currentStatus" required><br><br>
                
                <label for="estimatedCompletion">Estimated Completion:</label>
                <input type="date" id="estimatedCompletion" name="estimatedCompletion" required><br><br>
                
                <label for="spareParts">Spare Parts:</label>
                <textarea id="spareParts" name="spareParts" rows="4" cols="50" required></textarea><br><br>
                
                <label for="totalCost">Total Cost:</label>
                <input type="number" id="totalCost" name="totalCost" step="0.01" required><br><br>

                <label for="billImage">Bill Image:</label>
                <input type="file" id="billImage" name="billImage" required><br><br>
                
                <input type="submit" value="Add Tracking Details">
            </form>
        </section>
        <section>
            <h1>Existing Tracking Details</h1>
            <?php
            $servername = "localhost";
            $dbusername = "root";
            $dbpassword = "";
            $dbname = "omar";

            // Create connection
            $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetch tracking details from the database
            $sql = "SELECT * FROM TrackingDetails";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<table>";
                echo "<thead><tr><th>ID</th><th>Truck Number</th><th>Current Status</th><th>Estimated Completion</th><th>Spare Parts</th><th>Total Cost</th><th>Bill Image</th><th>Action</th></tr></thead>";
                echo "<tbody>";
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>{$row['id']}</td>";
                    echo "<td>{$row['truckNumber']}</td>";
                    echo "<td>{$row['currentStatus']}</td>";
                    echo "<td>{$row['estimatedCompletion']}</td>";
                    echo "<td>{$row['spareParts']}</td>";
                    echo "<td>{$row['totalCost']}</td>";
                    echo "<td><img src='{$row['billImage']}' alt='Bill Image' width='100'></td>";
                    echo "<td><a href='{$_SERVER["PHP_SELF"]}?delete={$row['id']}' class='delete-link' onclick='return confirm(\"Are you sure you want to delete this record?\");'>Delete</a></td>";
                    echo "</tr>";
                }
                echo "</tbody>";
                echo "</table>";
            } else {
                echo "<p>No tracking details found.</p>";
            }

            $conn->close();
            ?>
        </section>
    </main>
</body>
</html>
