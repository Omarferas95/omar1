<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/x-icon" href="images/icon.ico">
    <title>Al-Khatib Truck Repair Shop</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .contact-info {
            margin-bottom: 20px;
        }
        .contact-info p {
            font-size: 16px;
            color: #002A54;
            line-height: 1.6;
        }
        .contact-info a {
            color: #002A54;
            text-decoration: none;
            font-weight: bold;
        }
        .contact-info a:hover {
            text-decoration: underline;
        }
        .contact-form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .contact-form input, .contact-form textarea {
            width: 100%;
            max-width: 400px;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .contact-form button {
            padding: 10px 20px;
            color: white;
            background-color: #002A54;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .contact-form button:hover {
            background-color: #E4711C;
        }
        form {
            margin-top: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"],
        input[type="email"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #002A54;
            border-radius: 5px;
            box-sizing: border-box;
        }
        textarea {
            resize: vertical;
        }
        button {
            background-color: #002A54;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #E4711C;
        }
        button:active {
            background-color: #E4711C;
        }
    </style>
</head>
<body>
    <header>
        <img src="images/logo.PNG" alt="Al-Khatib Logo">
        <nav>
            <ul>
                <li><a href="home.php" class="active">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="services.php">Services</a></li>
                <li><a href="products.html">Products</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section id="contact">
            <h1>Contact Us</h1>
            <div class="contact-info">
                <h4>Contact info</h4>
                <p>Contact Number: +968 92715584 , +968 91166719</p>
                <p>WhatsApp: <a href="tel:+96898879796">+968 98879796</a></p>
                <p>Email: <a href="mailto:Omarferas95@gmail.com">Omarferas95@gmail.com</a></p>
                <p>Instagram: <a href="https://instagram.com/alkhatib_trucks/" target="_blank">Al-Khatib_Trucks</a></p>
                <p>Facebook: <a href="https://www.facebook.com/people/Al-Khatib-Trucks/61550995826185/?ref=xav_ig_profile_web" target="_blank">Al-Khatib Trucks</a></p>
            </div>
            <form action="" method="post">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" placeholder="Name" required>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="Email" required>
                <label for="message">Message:</label>
                <textarea id="message" name="message" placeholder="Message" rows="5" required></textarea>
                <button type="submit">Send</button>
            </form>
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $servername = "localhost";
                $dbusername = "root";
                $dbpassword = "";
                $dbname = "omar";

                $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $name = $conn->real_escape_string($_POST['name']);
                $email = $conn->real_escape_string($_POST['email']);
                $message = $conn->real_escape_string($_POST['message']);

                $sql = "INSERT INTO messages (name, email, message) VALUES ('$name', '$email', '$message')";

                if ($conn->query($sql) === TRUE) {
                    echo "<p>Message sent successfully!</p>";
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }

                $conn->close();
            }
            ?>
        </section>
    </main>
    <footer>
        <p>&copy; 2024 Al-Khatib Truck Repair Shop</p>
    </footer>
</body>
</html>
