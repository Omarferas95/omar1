<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/ico" href="images/icon.ico">
    <title>Al-Khatib Truck Repair Shop</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .hero {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: #002A54;
            position: relative;
            z-index: 1;
        }

        .hero-content {
            max-width: 600px;
            padding: 20px;
        }

        .hero h1 {
            font-size: 3em;
            margin-bottom: 20px;
        }

        .hero p {
            font-size: 1.2em;
            margin-bottom: 30px;
        }

        .hero button {
            background-color: #002A54;
            color: #fff;
            padding: 15px 30px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.2em;
            transition: background-color 0.3s ease;
        }

        .hero button:hover {
            background-color: #E4711C;
        }

        .hero button:active {
            background-color: #002A54;
        }

        .features {
            background-color: #f8f8f8;
            padding: 50px 0;
            text-align: center;
        }

        .features h2 {
            font-size: 2.5em;
            margin-bottom: 40px;
        }

        .feature-item {
            display: inline-block;
            width: 30%;
            margin: 1.66%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            background-color: #fff;
            padding: 20px;
            transition: transform 0.3s ease;
        }

        .feature-item:hover {
            transform: translateY(-10px);
        }

        .feature-item img {
            width: 100%;
            border-radius: 8px 8px 0 0;
        }

        .feature-item h3 {
            font-size: 1.5em;
            margin: 20px 0 10px;
        }

        .feature-item p {
            font-size: 1em;
            color: #555;
        }

        .testimonials {
            background-color: #fff;
            padding: 50px 0;
            text-align: center;
        }

        .testimonials h2 {
            font-size: 2.5em;
            margin-bottom: 40px;
        }

        .testimonial-item {
            display: inline-block;
            width: 30%;
            margin: 1.66%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            background-color: #f8f8f8;
            padding: 20px;
            transition: transform 0.3s ease;
        }

        .testimonial-item:hover {
            transform: translateY(-10px);
        }

        .testimonial-item img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin-bottom: 20px;
        }

        .testimonial-item p {
            font-size: 1em;
            color: #555;
            font-style: italic;
        }

        .testimonial-item h4 {
            font-size: 1.2em;
            margin-top: 20px;
            color: #333;
        }

        .logout-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #fff;
            color: #E4711C;
            border: none;
            border-radius: 15px;
            text-decoration: none;
            font-size: 1em;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease, color 0.3s ease;
            position: absolute;
            right: 10px;
            top: 150px;
        }

        .logout-button:hover {
            background-color: #E4711C;
            color: whitesmoke;
        }

        .login {
            display: inline-block;
            padding: 10px 20px;
            background-color: #fff;
            color: #E4711C;
            border: none;
            border-radius: 15px;
            text-decoration: none;
            font-size: 1em;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease, color 0.3s ease;
            position: absolute;
            right: 10px;
            top: 150px;
        }

        .login:hover {
            background-color: #E4711C;
            color: whitesmoke;
        }

        .nav-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #fff;
            color: #E4711C;
            border: none;
            border-radius: 15px;
            text-decoration: none;
            font-size: 1em;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease, color 0.3s ease;
            margin-right: 10px;
        }

        .nav-button:hover {
            background-color: #E4711C;
            color: whitesmoke;
        }

        .header-buttons {
            position: absolute;
            top: 20px;
            right: 45px;
            display: flex;
            flex-direction: row;
            align-items: center;
            gap: 10px;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <img src="images/logo.png" alt="Al-Khatib Truck Repair Shop Logo" class="logo">
            <?php
            $isLoggedIn = isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;
            $userRole = isset($_SESSION['roll']) ? $_SESSION['roll'] : null;

            if ($isLoggedIn) {
                echo '<div class="header-buttons">';
                if ($userRole === 1) {
                    echo '<a href="add_delete_product.php" class="nav-button">Add/Delete</a>';
                    echo '<a href="messag.php" class="nav-button">Show Messages</a>';
                    echo '<a href="addtracking.php" class="nav-button">Add Tracking Details</a>';
                }
                echo '</div>';
                echo '<form action="logout.php" method="post" class="logout-form">';
                echo '<input type="submit" value="Logout" class="logout-button">';
                echo '</form>';
                echo '<nav>
                    <ul>
                        <li><a href="home.php" class="active">Home</a></li>
                        <li><a href="about.html">About Us</a></li>
                        <li><a href="services.php">Services</a></li>
                        <li><a href="products.html">Products</a></li>
                        <li><a href="tracking.php">Tracking</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                    </ul>
                </nav>';
            } else {
                echo '<nav>
                    <ul>
                        <li><a href="home.php" class="active">Home</a></li>
                        <li><a href="about.html">About Us</a></li>
                        <li><a href="services.php">Services</a></li>
                        <li><a href="products.html">Products</a></li>
                        <li><a href="login.php" class="login">Login</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                    </ul>
                </nav>';
            }
            ?>
        </div>
    </header>
    
    <main>
        <section id="home" class="hero">
            <div class="hero-content">
                <h1>Welcome to Al-Khatib Truck Repair Shop</h1>
                <p>Make your truck look better with Al-Khatib Truck Repair Shop</p>
                <button onclick="redirectToWhatsApp()">Pick an appointment</button>

                <script>
                    function redirectToWhatsApp() {
                        const phoneNumber = '96898879796';
                        const message = encodeURIComponent(
                            `Your name: \nTruck model and make: \nNature of the issue: \nPreferred date and time for the appointment: \nContact number: \nEmail address: `
                        );
                        const url = `https://wa.me/${phoneNumber}?text=${message}`;
                        window.location.href = url;
                    }
                </script>
            </div>
        </section>
        
        <section id="features" class="features">
            <div class="container">
                <h2>Why Choose Us?</h2>
                <div class="feature-item">
                    <img src="images/exp.jpeg" alt="Expert Mechanics">
                    <h3>Expert Mechanics</h3>
                    <p>Our team of expert mechanics ensures top-notch repair services for your truck.</p>
                </div>
                <div class="feature-item">
                    <img src="images/OIP.jpeg" alt="Affordable Prices">
                    <h3>Affordable Prices</h3>
                    <p>We offer competitive pricing without compromising on quality.</p>
                </div>
                <div class="feature-item">
                    <img src="images/cust.jpeg" alt="Customer Satisfaction">
                    <h3>Customer Satisfaction</h3>
                    <p>Our priority is your satisfaction. We strive to exceed your expectations.</p>
                </div>
            </div>
        </section>

        <section id="testimonials" class="testimonials">
            <div class="container">
                <h2>What Our Customers Say</h2>
                <div class="testimonial-item">
                    <img src="images/omani.jpg" alt="Customer 1">
                    <p>"The best truck repair service I have ever experienced!"</p>
                    <h4>- Mohammed Al-Mansory</h4>
                </div>
                <div class="testimonial-item">
                    <img src="images/omani 1.jpg" alt="Customer 2">
                    <p>"Highly professional and affordable. Highly recommended!"</p>
                    <h4>- Salem Al-Mahrosy</h4>
                </div>
                <div class="testimonial-item">
                    <img src="images/omani 2.jpg" alt="Customer 3">
                    <p>"Outstanding customer service and top-notch repairs."</p>
                    <h4>- Ahmed Al-Roushde</h4>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2024 Al-Khatib Truck Repair Shop</p>
        </div>
    </footer>
</body>
</html>
