<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="images/ico" href="images/icon.ico">
    <title>Home</title>
    <link rel="stylesheet" href="loginstyles.css"/>
</head>
<body>
    <div class="container">
        <div class="center">
            <h1>Login</h1>
            <form action="" method="POST">
                <div class="txt_field">
                    <input type="text" name="username" required>
                    <span></span>
                    <label>Username</label>
                </div>
                <div class="txt_field">
                    <input type="password" name="password" required>
                    <span></span>
                    <label>Password</label>
                </div>
                <input name="submit" type="submit" value="Login">
                <div class="signup_link">
                    Not a Member? <a href="register.php">Signup</a>
                </div>
            </form>
        </div>
    </div>

    <?php
    // Start the session
    session_start();

    // Check if form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Retrieve form data
        $username = $_POST["username"];
        $password = $_POST["password"];

        // Connect to database (replace with your database credentials)
        $servername = "localhost";
        $dbusername = "root";
        $dbpassword = "";
        $dbname = "omar";

        $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Use prepared statements to prevent SQL injection
        $stmt = $conn->prepare("SELECT * FROM register WHERE email = ? AND password = ?");
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $result = $stmt->get_result();

        // If result has at least one row, set session variables and redirect to home page
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $_SESSION['loggedin'] = true;
            $_SESSION['roll'] = $user['roll']; // Assuming 'role' is the column name for the user role
            $_SESSION['username'] = $user['username']; // You can store other details as well

            // Redirect to home page
            header("Location: home.php");
            exit(); // Ensure subsequent code is not executed after redirection
        } else {
            echo "<script>alert('Invalid username or password');</script>";
        }

        $stmt->close();
        $conn->close();
    }
    ?>
</body>
</html>
