<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/ico" href="images/icon.ico">
    <title>Al-Khatib Truck Repair Shop</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        main {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    background: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
}

section {
    margin-bottom: 20px;
}

h2 {
    text-align: center;
    color: #333;
    font-size: 24px;
    border-bottom: 2px solid #eee;
    padding-bottom: 10px;
    margin-bottom: 20px;
}

#messages {
    margin-top: 20px;
}

.message {
    padding: 15px;
    border: 1px solid #ddd;
    border-radius: 5px;
    margin-bottom: 15px;
    background-color: #f9f9f9;
}

.message strong {
    color: #333;
    font-weight: bold;
}

.message hr {
    border: none;
    border-top: 1px solid #ddd;
    margin: 15px 0;
}

.message p {
    margin: 10px 0;
    color: #666;
}

.message span {
    display: block;
    margin: 5px 0;
}

hr {
    border: 0;
    height: 1px;
    background: #ddd;
    margin: 20px 0;
}

p {
    text-align: center;
    color: #666;
}
    </style>
</head>
<body>
    <header>
        <img src="images/logo.PNG">
        <nav>
            <ul>
                <li><a href="home.php" class="active">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="services.php">Services</a></li>
                <li><a href="products.html">Products</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <section>
            <h2>Messages</h2>
            <div id="messages">
                <?php
                // Database connection details
                $servername = "localhost";
                $dbusername = "root";
                $dbpassword = "";
                $dbname = "omar";

                // Create connection
                $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Fetch messages from the database
                $sql = "SELECT * FROM messages"; // Adjust the table name and column names as per your database
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<div class='message'><strong>Name:</strong> {$row['name']}<br><strong>Email:</strong> {$row['email']}<br><strong>Message:</strong> {$row['message']}</div><hr>";
                    }
                } else {
                    echo "<p>No messages found.</p>";
                }

                // Close the connection
                $conn->close();
                ?>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Al-Khatib Truck Repair Shop</p>
    </footer>
</body>
</html>
