<?php
session_start();

// Connect to database
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "omar";

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission for adding a product
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_product'])) {
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];

    // Handle file upload
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["product_image"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Ensure the uploads directory exists
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // Check if image file is an actual image or fake image
    $check = getimagesize($_FILES["product_image"]["tmp_name"]);
    if ($check !== false) {
        if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file)) {
            // File is valid, and was successfully uploaded
            $stmt = $conn->prepare("INSERT INTO products (name, price, image_path) VALUES (?, ?, ?)");
            $stmt->bind_param("sds", $product_name, $product_price, $target_file);
            $stmt->execute();
            $stmt->close();

            echo "<script>alert('Product added successfully');</script>";
        } else {
            echo "<script>alert('Sorry, there was an error uploading your file.');</script>";
        }
    } else {
        echo "<script>alert('File is not an image.');</script>";
    }
}

// Fetch all products
$result = $conn->query("SELECT * FROM products");

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/ico" href="images/icon.ico">
    <title>Al-Khatib Truck Repair Shop</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }
        .product-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: center;
            margin: 20px;
        }
        .product {
            background-color: #ffffff;
            border: 2px solid #002A54;
            border-radius: 8px;
            width: 150px;
            padding: 10px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            transition: transform 0.2s;
        }
        .product:hover {
            transform: translateY(-5px);
        }
        .product img {
            width: 100%;
            height: auto;
        }
        .product h3 {
            font-size: 16px;
            margin: 10px 0;
            color: #002A54;
        }
        .quantity-controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 10px;
        }
        .quantity-controls input {
            width: 50px;
            text-align: center;
        }
        .quantity-controls button {
            background-color: #002A54;
            border: none;
            color: white;
            padding: 5px 10px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .quantity-controls button:hover {
            background-color: #E4711C;
        }
        .add-to-cart {
            background-color: #002A54;
            color: white;
            padding: 5px 10px;
            border: none;
            cursor: pointer;
            margin-top: 10px;
            transition: background-color 0.3s;
            width: 100%;
        }
        .add-to-cart:hover {
            background-color: #E4711C;
        }
        .cart-container {
            margin: 20px;
            padding: 10px;
            border: 2px solid #002A54;
            border-radius: 8px;
            background-color: #ffffff;
        }
        .payment-button {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #002A54;
            color: #ffffff;
            font-size: 16px;
            text-decoration: none;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .payment-button:hover {
            background-color: #E4711C;
        }
    </style>
</head>
<body>
    <header>
        <img src="images/logo.PNG">
        <nav>
            <ul>
                <li><a href="home.php" class="active">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="services.php">Services</a></li>
                <li><a href="products.html">Products</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section class="product-container">
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="product">
                    <img src="<?php echo $row['image_path']; ?>" alt="Part Image">
                    <h3><?php echo $row['name']; ?> - <?php echo number_format($row['price'], 2); ?> OMR</h3>
                    <div class="quantity-controls">
                        <button onclick="changeQuantity('<?php echo $row['id']; ?>', -1)">-</button>
                        <input type="number" id="<?php echo $row['id']; ?>" value="0" min="0">
                        <button onclick="changeQuantity('<?php echo $row['id']; ?>', 1)">+</button>
                    </div>
                    <button class="add-to-cart" onclick="addToCart('<?php echo $row['name']; ?>', <?php echo $row['price']; ?>, '<?php echo $row['id']; ?>')">Add to Cart</button>
                </div>
            <?php endwhile; ?>
        </section>
        <div class="cart-container" id="cart-container">
            <h3>Shopping Cart</h3>
            <ul id="cart-items"></ul>
        </div>
        <a href="Payment.html" class="payment-button">Proceed to Payment</a>
    </main>
    <script>
        function changeQuantity(id, amount) {
            const input = document.getElementById(id);
            const currentValue = parseInt(input.value);
            const newValue = Math.max(currentValue + amount, 0);
            input.value = newValue;
        }

        function addToCart(name, price, id) {
            const quantity = parseInt(document.getElementById(id).value);
            if (quantity > 0) {
                let cart = JSON.parse(localStorage.getItem('cart')) || [];
                const existingItem = cart.find(item => item.id === id);
                if (existingItem) {
                    existingItem.quantity += quantity;
                } else {
                    cart.push({ name, price, quantity, id });
                }
                localStorage.setItem('cart', JSON.stringify(cart));
                alert(`${name} added to cart`);
                updateCartDisplay();
            } else {
                alert('Please select a quantity');
            }
        }

        function updateCartDisplay() {
            const cart = JSON.parse(localStorage.getItem('cart')) || [];
            const cartItems = document.getElementById('cart-items');
            cartItems.innerHTML = ''; // Clear previous items

            cart.forEach(item => {
                const li = document.createElement('li');
                li.textContent = `${item.name} - Quantity: ${item.quantity} - ${item.price * item.quantity} OMR`;
                cartItems.appendChild(li);
            });
        }

        document.addEventListener('DOMContentLoaded', updateCartDisplay);
    </script>
</body>
</html>
