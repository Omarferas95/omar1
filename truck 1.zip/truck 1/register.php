<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$database = "omar";

$conn = mysqli_connect($servername, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];

    if ($password != $cpassword) {
        echo "Passwords do not match.";
    } else {
        $sql = "INSERT INTO Register (name, email, password) VALUES ('$name', '$email', '$password')";

        if (mysqli_query($conn, $sql)) {
            header("Location: login.php");
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="images/ico" href="images/icon.ico">
    <title>Register</title>
    <link rel="stylesheet" href="registerstyles.css"/>
</head>
<body>
<div class="container">
    <div class="center">
        <h1>Register</h1>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="txt_field">
                <input type="text" name="name" required>
                <span></span>
                <label>Name</label>
            </div>
            <div class="txt_field">
                <input type="email" name="email" required>
                <span></span>
                <label>Email</label>
            </div>
            <div class="txt_field">
                <input type="password" name="password" required>
                <span></span>
                <label>Password</label>
            </div>
            <div class="txt_field">
                <input type="password" name="cpassword" required>
                <span></span>
                <label>Confirm Password</label>
            </div>
            <input name="submit" type="submit" value="Sign Up">
            <div class="signup_link">
                Have an Account? <a href="login.php">Login Here</a>
            </div>
        </form>
    </div>
</div>
</body>
</html>

<?php
mysqli_close($conn);
?>
