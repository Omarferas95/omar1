<?php
session_start();

// Connect to database
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "omar";

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all services
$service_result = $conn->query("SELECT * FROM services");

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/ico" href="images/icon.ico">
    <title>Al-Khatib Truck Repair Shop - Our Services</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .services-section {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            text-align: center;
        }

        .services-section h1 {
            color: #002A54;
        }

        .services-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }

        .service {
            flex: 1 1 300px;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            background: #f9f9f9;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 300px;
            transition: transform 0.3s;
        }

        .service:hover {
            transform: scale(1.05);
        }

        .service img {
            width: 100%;
            height: auto;
            border-radius: 10px;
        }

        .service h3 {
            margin: 20px 0;
            color: #002A54;
            text-align: center;
        }

        .service ul {
            list-style-type: disc;
            padding-left: 20px;
            text-align: left;
        }

        .service ul li {
            margin-bottom: 10px;
            
        }
    </style>
</head>
<body>
    <header>
        <img src="images/logo.PNG" alt="Logo">
        <nav>
            <ul>
                <li><a href="home.php" class="active">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="services.php">Services</a></li>
                <li><a href="products.html">Products</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section class="services-section">
            <h1>Our Services</h1>
            <div class="services-container">
                <?php while ($row = $service_result->fetch_assoc()): ?>
                    <div class="service">
                        <img src="<?php echo htmlspecialchars($row['image_path']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>">
                        <h3><?php echo htmlspecialchars($row['name']); ?></h3>
                        <ul>
                            <?php 
                            $description_lines = explode("*", $row['description']);
                            $last_line = array_pop($description_lines); // Remove and get the last bullet point
                            foreach ($description_lines as $line) {
                                if (trim($line)) {
                                    echo "<li>" . htmlspecialchars($line) . "</li>";
                                }
                            }
                            // Split the last line by the first period to create a new paragraph
                            $parts = explode('.', $last_line, 2);
                            if (count($parts) == 2) {
                                echo "<li>" . htmlspecialchars($parts[0]) . ".<p>" . htmlspecialchars($parts[1]) . "</p></li>";
                            } else {
                                echo "<li>" . htmlspecialchars($last_line) . "</li>";
                            }
                            ?>
                        </ul>
                    </div>
                <?php endwhile; ?>
            </div>
        </section>
    </main>
    <footer>
        <p>&copy; 2024 Al-Khatib Truck Repair Shop</p>
    </footer>
</body>
</html>
