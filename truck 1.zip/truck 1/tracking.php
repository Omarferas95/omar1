<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/ico" href="images/icon.ico">
    <title>Al-Khatib Truck Repair Shop - Tracking</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        h1, h2, h3 {
            color: #002A54;
        }

        main {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
        }

        section {
            background: #fff;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        section h2 {
            border-bottom: 2px solid #002A54;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="text"] {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #002A54;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #E4711C;
        }

        #tracking-status {
            background-color: #ecf0f1;
            padding: 20px;
            border-radius: 5px;
        }

        #tracking-status p {
            margin: 10px 0;
        }

        #how-it-works ul {
            list-style: none;
            padding: 0;
        }

        #how-it-works li {
            margin-bottom: 10px;
            padding: 10px;
            background-color: #ecf0f1;
            border-radius: 5px;
        }

        #how-it-works strong {
            color: #002A54;
        }

        .faq-item {
            margin-bottom: 20px;
        }

        .faq-item h3 {
            font-size: 1.2em;
            margin-bottom: 10px;
        }

        .faq-item p {
            margin: 0;
        }

        .review {
            background-color: #ecf0f1;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .review p {
            margin: 0;
        }

        @media (max-width: 768px) {
            main {
                width: 95%;
                padding: 10px;
            }

            button {
                font-size: 14px;
            }
        }

        .bill-image {
            margin-top: 20px;
            text-align: center;
        }

        .bill-image img {
            max-width: 100%;
            height: auto;
            border-radius: 5px;
        }

        .bill-actions {
            text-align: center;
            margin-top: 10px;
        }

        .bill-actions button {
            margin: 5px;
        }
    </style>
</head>
<body>
    <header>
        <img src="images/logo.PNG" alt="Al-Khatib Truck Repair Shop Logo" class="logo">
        <nav>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="services.php">Services</a></li>
                <li><a href="products.html">Products</a></li>
                <li><a href="tracking.php" class="active">Tracking</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section id="tracking">
            <h1>Track Your Truck</h1>
            <p>Stay updated with the status of your truck. Enter your tracking number below to get real-time updates on your vehicle.</p>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <label for="tracking-number">Tracking Number:</label>
                <input type="text" id="tracking-number" name="tracking-number" required>
                <button type="submit">Track</button>
            </form>
        </section>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $servername = "localhost";
            $dbusername = "root";
            $dbpassword = "";
            $dbname = "omar";

            // Create connection
            $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $trackingNumber = $_POST['tracking-number'];
            $sql = "SELECT * FROM TrackingDetails WHERE truckNumber = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $trackingNumber);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                echo '<section id="detailed-info">';
                echo '<h2>Tracking Details</h2>';
                echo '<div id="tracking-status">';
                echo '<p><strong>Truck Number:</strong> ' . htmlspecialchars($row["truckNumber"]) . '</p>';
                echo '<p><strong>Current Status:</strong> ' . htmlspecialchars($row["currentStatus"]) . '</p>';
                echo '<p><strong>Estimated Completion:</strong> ' . htmlspecialchars($row["estimatedCompletion"]) . '</p>';
                echo '<p><strong>Spare Parts:</strong> ' . htmlspecialchars($row["spareParts"]) . '</p>';
                echo '<p><strong>Total Cost:</strong> $' . htmlspecialchars($row["totalCost"]) . '</p>';
                if (!empty($row["billImage"])) {
                    echo '<div class="bill-image">';
                    echo '<img src="' . htmlspecialchars($row["billImage"]) . '" alt="Bill Image">';
                    echo '</div>';
                    echo '<div class="bill-actions">';
                    echo '<a href="' . htmlspecialchars($row["billImage"]) . '" download><button>Download Bill</button></a>';
                    echo '<button onclick="window.print()">Print Bill</button>';
                    echo '</div>';
                }
                echo '</div>';
                echo '</section>';
            } else {
                echo '<section id="detailed-info">';
                echo '<h2>Tracking Details</h2>';
                echo '<div id="tracking-status">';
                echo '<p>No tracking details found for the provided tracking number.</p>';
                echo '</div>';
                echo '</section>';
            }

            $stmt->close();
            $conn->close();
        }
        ?>

        <section id="how-it-works">
            <h2>How It Works</h2>
            <p>Our tracking system provides real-time updates on the status of your truck. Here's how it works:</p>
            <ul>
                <li><strong>Step 1:</strong> Drop off your truck at our repair shop.</li>
                <li><strong>Step 2:</strong> Receive a unique tracking number.</li>
                <li><strong>Step 3:</strong> Enter the tracking number on our website to see the current status and location of your truck.</li>
                <li><strong>Step 4:</strong> Get notified when your truck is ready for pickup.</li>
            </ul>
        </section>

        <section id="faq">
            <h2>Frequently Asked Questions</h2>
            <div class="faq-item">
                <h3>How do I get a tracking number?</h3>
                <p>Tracking numbers are provided at the time of drop-off at our shop. Make sure to keep it safe to track your truck's repair status.</p>
            </div>
            <div class="faq-item">
                <h3>What should I do if I lose my tracking number?</h3>
                <p>If you lose your tracking number, please contact our customer support team for assistance.</p>
            </div>
        </section>

        <section id="customer-reviews">
            <h2>Customer Reviews</h2>
            <p>See what our customers have to say about our services:</p>
            <div class="review">
                <p>"Al-Khatib Truck Repair Shop provided excellent service. The tracking system kept me informed throughout the repair process." - <strong>Talal Al-Soury</strong></p>
            </div>
            <div class="review">
                <p>"Highly recommend this shop! The staff is professional, and the tracking feature is very convenient." - <strong>Ahmed Al-Bady</strong></p>
            </div>
        </section>
    </main>
    <footer>
        <p>&copy; 2024 Al-Khatib Truck Repair Shop</p>
    </footer>
</body>
</html>
